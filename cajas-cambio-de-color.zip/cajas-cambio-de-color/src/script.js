//desafio cajas//

//desafio 1: cambiar el título .getElementById//

document.getElementById("btn-titulo").addEventListener("click",()=>
{
  const titulo =
        document.getElementById("titulo");
  titulo.textContent = "Marijose Islas!";
  
});

//desafio 2: cambiar el color del fondo de todas las cajas getElementsByClassName//

document.getElementById("btn-cajas").addEventListener("click",()=>
{
 const cajas =
  document.getElementsByClassName("caja")
 for (let i = 0; i < cajas.length; i++)
   {
     cajas[i].style.backgroundColor = "pink";
   } 
});

//cambiar el color de la primera caja con querySelector//

document.getElementById("btn-primera").addEventListener("click",()=>
{
  const primeracaja =document.querySelector(".caja");

  primeracaja.style.backgroundColor = "red";
  
});

//desafio 4: cambair el borde de todas las cajas .querySelectorAll//

document.getElementById("btn-bordes").addEventListener("click",()=>
{
  const cajas =
        document.querySelectorAll(".caja");
  cajas.forEach(caja=>{
    caja.style.border = "4px solid purple"
 });
});  